jQuery(document).ready(function(){
  
  jQuery('pre').addClass('prettyprint linenums');
  
  //syntax highlighter
  prettyPrint();
  
});